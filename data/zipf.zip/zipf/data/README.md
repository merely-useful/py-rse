Full text of novels downloaded from Project Gutenberg.

-   What is this?: text files (newline-terminated)
-   Source(s): Project Gutenberg, https://www.gutenberg.org/
-   License: public domain
    -   Each file contains the text of its license.
    -   See https://www.gutenberg.org/wiki/Gutenberg:Permission_How-To for details.
-   Downloaded: 2018-08-15
-   Contact: Greg Wilson <gvwilson@third-bit.com>
-   Spatial Applicability: N/A
-   Temporal Applicability: N/A
-   Notes:
    -   Files contain some 8-bit characters (e.g., curly quotation marks).
    -   Files contain bibliographic information at the start.
    -   Files contain errata, license information, and other material at the end.
